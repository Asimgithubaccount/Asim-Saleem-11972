                                                                                       DM Assignment # 01

Group Member # 01:
Student Id: 11972
Name: Asim saleem

Group Member # 02:
Student Id: 11717
Name: Hamza Usman


Group Member # 03:
Student Id: 13039
Name: Aun Hassan Ali

                                                                                                 Task  01:
 
Take input from user and show [Transitive Closure](#TransitiveClosure) in output div.

                                                                                            Definitions:

                                                              <a name="TransitiveClosure">Transitive Closure</a>
Transitive Closure can be defined as an extension or superset of a binary relation such that whenever (a,b) and (b,c) are in the extension, (a,c) is also in the extension.
